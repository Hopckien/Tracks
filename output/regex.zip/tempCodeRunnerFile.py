for l in labels:
#     print(l)